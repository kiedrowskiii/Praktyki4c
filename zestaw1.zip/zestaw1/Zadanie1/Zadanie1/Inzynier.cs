using System;

namespace ZadanieInzynier
{
    public enum Skutecznosc
    {
        SLABY = 1,
        DOBRY = 2,
        WYBITNY = 3
    }

    public class Inzynier
    {
        public string Imie;
        public string Nazwisko;
        public Skutecznosc Skutecznosc;
        public int LiczbaProjektow;

        public static int WszystkieProjektyFirmy = 0;

        public Inzynier(string imie, string nazwisko, Skutecznosc skutecznosc, int liczbaProjektow)
        {
            Imie = imie;
            Nazwisko = nazwisko;
            Skutecznosc = skutecznosc;
            LiczbaProjektow = liczbaProjektow;
        }

        public void Buduj()
        {
            int iloscBudowanych = (int)Skutecznosc; 

            Console.WriteLine($"{Imie} {Nazwisko} buduje {iloscBudowanych} projekt(y).");

            LiczbaProjektow += iloscBudowanych;
            WszystkieProjektyFirmy += iloscBudowanych;
        }

        public void Pokaz()
        {
            Console.WriteLine($"{Imie} {Nazwisko} - zrealizowanych projektow: {LiczbaProjektow} (skutecznosc: {Skutecznosc})");
        }

        public static void PokazGlobalneProjekty()
        {
            Console.WriteLine($"Sumaryczna liczba projektow zrealizowanych przez firme: {WszystkieProjektyFirmy}");
        }
    }
}
