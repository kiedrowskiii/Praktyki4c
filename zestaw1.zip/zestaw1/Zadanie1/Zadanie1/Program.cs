﻿using System;

namespace ZadanieInzynier
{
    class Program
    {
        static void Main(string[] args)
        {
            Inzynier jan = new Inzynier("Jan", "Kowalski", Skutecznosc.SLABY, 0);
            Inzynier anna = new Inzynier("Anna", "Nowak", Skutecznosc.DOBRY, 0);
            Inzynier piotr = new Inzynier("Piotr", "Wisniewski", Skutecznosc.WYBITNY, 0);

            jan.Buduj();
            anna.Buduj();
            piotr.Buduj();
            piotr.Buduj();

            Console.WriteLine();

            jan.Pokaz();
            anna.Pokaz();
            piotr.Pokaz();

            Console.WriteLine();

            Inzynier.PokazGlobalneProjekty();
        }
    }
}
