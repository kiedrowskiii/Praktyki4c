﻿using System;

namespace Zadanie3
{
    public enum Skutecznosc
    {
        SLABY = 1,
        DOBRY = 2,
        WYBITNY = 3
    }

    public class Inzynier
    {
        public string Imie;
        public string Nazwisko;
        public Skutecznosc Skutecznosc;
        public int LiczbaProjektow;

        public static int WszystkieProjektyFirmy = 0;
        public Inzynier(string imie, string nazwisko, Skutecznosc skutecznosc, int liczbaProjektow)
        {
            Imie = imie;
            Nazwisko = nazwisko;
            Skutecznosc = skutecznosc;

            LiczbaProjektow = liczbaProjektow < 0 ? 0 : liczbaProjektow;
        }

        public void Buduj()
        {
            int iloscBudowanych = (int)Skutecznosc; 

            Console.WriteLine($"{Imie} {Nazwisko} buduje {iloscBudowanych} projekt(y).");

            LiczbaProjektow += iloscBudowanych;
            WszystkieProjektyFirmy += iloscBudowanych;

            Awansuj();
        }

        public void Awansuj()
        {
            if (Skutecznosc == Skutecznosc.SLABY && LiczbaProjektow >= 10)
            {
                Skutecznosc = Skutecznosc.DOBRY;
                Console.WriteLine($">>> {Imie} {Nazwisko} awansowal: SLABY -> DOBRY (projekty: {LiczbaProjektow})");
            }
            else if (Skutecznosc == Skutecznosc.DOBRY && LiczbaProjektow > 20)
            {
                Skutecznosc = Skutecznosc.WYBITNY;
                Console.WriteLine($">>> {Imie} {Nazwisko} awansowal: DOBRY -> WYBITNY (projekty: {LiczbaProjektow})");
            }
        }

        public void Pokaz()
        {
            Console.WriteLine($"{Imie} {Nazwisko} - zrealizowanych projektow: {LiczbaProjektow} (skutecznosc: {Skutecznosc})");
        }

        public static void PokazGlobalneProjekty()
        {
            Console.WriteLine($"Sumaryczna liczba projektow zrealizowanych przez firme: {WszystkieProjektyFirmy}");
        }
    }
}