﻿using System;
using Zadanie3;

namespace Zadanie3
{
    class Program
    {
        static void Main(string[] args)
        {
            Inzynier ola = new Inzynier("Ola", "Zawadzka", Skutecznosc.SLABY, -5);
            Console.WriteLine($"Poczatkowa liczba projektow Oli (mimo podania -5): {ola.LiczbaProjektow}");
            Console.WriteLine();

            for (int i = 0; i < 10; i++)
            {
                ola.Buduj();
            }

            Console.WriteLine();
            ola.Pokaz();
            Console.WriteLine();

            for (int i = 0; i < 6; i++)
            {
                ola.Buduj();
            }

            Console.WriteLine();
            ola.Pokaz();
            Console.WriteLine();

            Inzynier.PokazGlobalneProjekty();
        }
    }
}
