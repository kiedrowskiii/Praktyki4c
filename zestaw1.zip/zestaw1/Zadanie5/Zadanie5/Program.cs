﻿using System;
using System.Collections.Generic;

namespace ZadanieInzynier
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Inzynier> zespol = new List<Inzynier>
            {
                new Inzynier("Jan", "Kowalski", Skutecznosc.SLABY, 0),
                new Inzynier("Anna", "Nowak", Skutecznosc.DOBRY, 0),
                new Inzynier("Piotr", "Wisniewski", Skutecznosc.WYBITNY, 0)
            };

            foreach (Inzynier inz in zespol)
            {
                for (int i = 0; i < 3; i++)
                {
                    inz.Buduj();
                }
            }

            Console.WriteLine();

            foreach (Inzynier inz in zespol)
            {
                inz.Pokaz();
            }

            Console.WriteLine();
            zespol[0].PorownajZ(zespol[1]); 
            zespol[1].PorownajZ(zespol[2]);
            zespol[0].PorownajZ(zespol[2]);

            Console.WriteLine();
            Inzynier.PokazGlobalneProjekty();
            Console.WriteLine($"Aktualny rekord projektow pojedynczego inzyniera: {Inzynier.RekordProjektow}");
            Console.WriteLine($"Srednia projektow na inzyniera: {Inzynier.SredniaProjektowNaInzyniera():F2}");
        }
    }
}
