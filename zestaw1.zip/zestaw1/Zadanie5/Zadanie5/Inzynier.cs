﻿using System;

namespace ZadanieInzynier
{
    public enum Skutecznosc
    {
        SLABY = 1,
        DOBRY = 2,
        WYBITNY = 3
    }

    public class Inzynier
    {
        public string Imie;
        public string Nazwisko;
        public Skutecznosc Skutecznosc;
        public int LiczbaProjektow;

        public static int WszystkieProjektyFirmy = 0;
        public static int LiczbaInzynierow = 0;
        public static int RekordProjektow = 0;

        public Inzynier(string imie, string nazwisko, Skutecznosc skutecznosc, int liczbaProjektow)
        {
            Imie = imie;
            Nazwisko = nazwisko;
            Skutecznosc = skutecznosc;

            LiczbaProjektow = liczbaProjektow < 0 ? 0 : liczbaProjektow;

            LiczbaInzynierow++;
        }

        public void Buduj()
        {
            int iloscBudowanych = (int)Skutecznosc; 

            Console.WriteLine($"{Imie} {Nazwisko} buduje {iloscBudowanych} projekt(y).");

            LiczbaProjektow += iloscBudowanych;
            WszystkieProjektyFirmy += iloscBudowanych;

            Awansuj();

            if (LiczbaProjektow > RekordProjektow)
            {
                RekordProjektow = LiczbaProjektow;
                Console.WriteLine($"*** Nowy rekord firmy! {Imie} {Nazwisko} ma juz {RekordProjektow} projekty. ***");
            }
        }

        public void Awansuj()
        {
            if (Skutecznosc == Skutecznosc.SLABY && LiczbaProjektow >= 10)
            {
                Skutecznosc = Skutecznosc.DOBRY;
                Console.WriteLine($">>> {Imie} {Nazwisko} awansowal: SLABY -> DOBRY (projekty: {LiczbaProjektow})");
            }
            else if (Skutecznosc == Skutecznosc.DOBRY && LiczbaProjektow > 20)
            {
                Skutecznosc = Skutecznosc.WYBITNY;
                Console.WriteLine($">>> {Imie} {Nazwisko} awansowal: DOBRY -> WYBITNY (projekty: {LiczbaProjektow})");
            }
        }

        public void Pokaz()
        {
            Console.WriteLine($"{Imie} {Nazwisko} - zrealizowanych projektow: {LiczbaProjektow} (skutecznosc: {Skutecznosc})");
        }
        public void PorownajZ(Inzynier innyInzynier)
        {
            int roznica = LiczbaProjektow - innyInzynier.LiczbaProjektow;

            if (roznica > 0)
            {
                Console.WriteLine($"{Imie} {Nazwisko} wyprzedza {innyInzynier.Imie} {innyInzynier.Nazwisko} o {roznica} projekt(y).");
            }
            else if (roznica < 0)
            {
                Console.WriteLine($"{innyInzynier.Imie} {innyInzynier.Nazwisko} wyprzedza {Imie} {Nazwisko} o {-roznica} projekt(y).");
            }
            else
            {
                Console.WriteLine($"{Imie} {Nazwisko} i {innyInzynier.Imie} {innyInzynier.Nazwisko} maja taka sama liczbe projektow ({LiczbaProjektow}).");
            }
        }

        public static void PokazGlobalneProjekty()
        {
            Console.WriteLine($"Sumaryczna liczba projektow zrealizowanych przez firme: {WszystkieProjektyFirmy}");
        }

        public static double SredniaProjektowNaInzyniera()
        {
            if (LiczbaInzynierow == 0)
            {
                return 0;
            }

            return (double)WszystkieProjektyFirmy / LiczbaInzynierow;
        }
    }
}