﻿using System;
using System.Collections.Generic;

namespace Zadanie4
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Inzynier> zespol = new List<Inzynier>
            {
                new Inzynier("Jan", "Kowalski", Skutecznosc.SLABY, 0),
                new Inzynier("Anna", "Nowak", Skutecznosc.DOBRY, 0),
                new Inzynier("Piotr", "Wisniewski", Skutecznosc.WYBITNY, 0)
            };

            Console.WriteLine($"Liczba zatrudnionych inzynierow: {Inzynier.LiczbaInzynierow}");
            Console.WriteLine();

            foreach (Inzynier inz in zespol)
            {
                for (int i = 0; i < 3; i++)
                {
                    inz.Buduj();
                }
            }

            Console.WriteLine();

            foreach (Inzynier inz in zespol)
            {
                inz.Pokaz();
            }

            Console.WriteLine();
            Inzynier.PokazGlobalneProjekty();
            Console.WriteLine($"Liczba zatrudnionych inzynierow: {Inzynier.LiczbaInzynierow}");
            Console.WriteLine($"Srednia projektow na inzyniera: {Inzynier.SredniaProjektowNaInzyniera():F2}");
        }
    }
}
