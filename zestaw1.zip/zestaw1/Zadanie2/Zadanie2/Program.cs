﻿using System;
using System.Collections.Generic;

namespace Zadanie2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Inzynier> zespol = new List<Inzynier>
            {
                new Inzynier("Jan", "Kowalski", Skutecznosc.SLABY, 0),
                new Inzynier("Anna", "Nowak", Skutecznosc.DOBRY, 0),
                new Inzynier("Piotr", "Wisniewski", Skutecznosc.WYBITNY, 0)
            };

            foreach (Inzynier inz in zespol)
            {
                for (int i = 0; i < 3; i++)
                {
                    inz.Buduj();
                }
            }

            Console.WriteLine();
            foreach (Inzynier inz in zespol)
            {
                inz.Pokaz();
            }

            Console.WriteLine();

            Inzynier.PokazGlobalneProjekty();

            int sumaRecznie = 0;
            foreach (Inzynier inz in zespol)
            {
                sumaRecznie += inz.LiczbaProjektow;
            }

            Console.WriteLine($"Suma projektow policzona recznie: {sumaRecznie}");

            if (sumaRecznie == Inzynier.WszystkieProjektyFirmy)
            {
                Console.WriteLine("Weryfikacja OK - pole statyczne poprawnie zsumowalo wyniki wszystkich pracownikow.");
            }
            else
            {
                Console.WriteLine("Blad! Pole statyczne nie zgadza sie z suma projektow inzynierow.");
            }
        }
    }
}
