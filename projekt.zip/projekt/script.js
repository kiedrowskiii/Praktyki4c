

function getUsers() {
  const data = localStorage.getItem('taskapp_users');
  return data ? JSON.parse(data) : [];
}

function saveUsers(users) {
  localStorage.setItem('taskapp_users', JSON.stringify(users));
}

function getCurrentUser() {
  return localStorage.getItem('taskapp_current_user');
}

function setCurrentUser(username) {
  localStorage.setItem('taskapp_current_user', username);
}

function clearCurrentUser() {
  localStorage.removeItem('taskapp_current_user');
}

function getTasks(username) {
  const data = localStorage.getItem('taskapp_tasks_' + username);
  return data ? JSON.parse(data) : [];
}

function saveTasks(username, tasks) {
  localStorage.setItem('taskapp_tasks_' + username, JSON.stringify(tasks));
}


const loginSection = document.getElementById('login-section');
const registerSection = document.getElementById('register-section');
const dashboardSection = document.getElementById('dashboard-section');

const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const taskForm = document.getElementById('task-form');

const loginError = document.getElementById('login-error');
const registerError = document.getElementById('register-error');
const registerSuccess = document.getElementById('register-success');

const taskList = document.getElementById('task-list');
const taskInput = document.getElementById('task-input');
const taskPriority = document.getElementById('task-priority');
const emptyMessage = document.getElementById('empty-message');
const welcomeMessage = document.getElementById('welcome-message');

const progressText = document.getElementById('progress-text');
const progressFill = document.getElementById('progress-fill');

let currentFilter = 'all';


function showSection(section) {
  loginSection.classList.add('hidden');
  registerSection.classList.add('hidden');
  dashboardSection.classList.add('hidden');
  section.classList.remove('hidden');
}

document.getElementById('show-register').addEventListener('click', function (e) {
  e.preventDefault();
  registerError.textContent = '';
  registerSuccess.textContent = '';
  showSection(registerSection);
});

document.getElementById('show-login').addEventListener('click', function (e) {
  e.preventDefault();
  loginError.textContent = '';
  showSection(loginSection);
});


registerForm.addEventListener('submit', function (e) {
  e.preventDefault();

  const username = document.getElementById('register-username').value.trim();
  const password = document.getElementById('register-password').value;
  const passwordConfirm = document.getElementById('register-password-confirm').value;

  registerError.textContent = '';
  registerSuccess.textContent = '';

  if (password !== passwordConfirm) {
    registerError.textContent = 'Hasła nie są identyczne.';
    return;
  }

  const users = getUsers();
  const exists = users.some(function (u) {
    return u.username.toLowerCase() === username.toLowerCase();
  });

  if (exists) {
    registerError.textContent = 'Ta nazwa użytkownika jest już zajęta.';
    return;
  }

  users.push({ username: username, password: password });
  saveUsers(users);

  registerSuccess.textContent = 'Konto utworzone. Za chwilę przejdziesz do logowania.';
  registerForm.reset();

  setTimeout(function () {
    registerSuccess.textContent = '';
    showSection(loginSection);
  }, 1400);
});


loginForm.addEventListener('submit', function (e) {
  e.preventDefault();

  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;

  const users = getUsers();
  const user = users.find(function (u) {
    return u.username.toLowerCase() === username.toLowerCase() && u.password === password;
  });

  if (!user) {
    loginError.textContent = 'Nieprawidłowa nazwa użytkownika lub hasło.';
    return;
  }

  loginError.textContent = '';
  setCurrentUser(user.username);
  loginForm.reset();
  enterDashboard(user.username);
});

document.getElementById('logout-btn').addEventListener('click', function () {
  clearCurrentUser();
  showSection(loginSection);
});


function enterDashboard(username) {
  welcomeMessage.textContent = 'Witaj, ' + username + '!';
  currentFilter = 'all';
  document.querySelectorAll('.filter-btn').forEach(function (b) {
    b.classList.toggle('active', b.dataset.filter === 'all');
  });
  showSection(dashboardSection);
  renderTasks();
}

taskForm.addEventListener('submit', function (e) {
  e.preventDefault();

  const username = getCurrentUser();
  const text = taskInput.value.trim();
  if (!text) return;

  const tasks = getTasks(username);
  tasks.push({
    id: Date.now(),
    text: text,
    priority: taskPriority.value,
    done: false
  });

  saveTasks(username, tasks);
  taskInput.value = '';
  taskInput.focus();
  renderTasks();
});

document.querySelectorAll('.filter-btn').forEach(function (btn) {
  btn.addEventListener('click', function () {
    document.querySelectorAll('.filter-btn').forEach(function (b) {
      b.classList.remove('active');
    });
    btn.classList.add('active');
    currentFilter = btn.dataset.filter;
    renderTasks();
  });
});

function renderTasks() {
  const username = getCurrentUser();
  const tasks = getTasks(username);

  let filteredTasks = tasks;
  if (currentFilter === 'active') {
    filteredTasks = tasks.filter(function (t) { return !t.done; });
  } else if (currentFilter === 'done') {
    filteredTasks = tasks.filter(function (t) { return t.done; });
  }

  taskList.innerHTML = '';
  emptyMessage.classList.toggle('hidden', filteredTasks.length > 0);

  filteredTasks.forEach(function (task) {
    const li = document.createElement('li');
    li.className = 'task-item priority-' + task.priority + (task.done ? ' done' : '');

    li.innerHTML =
      '<input type="checkbox" class="check-input" aria-label="Oznacz jako wykonane: ' + escapeHtml(task.text) + '"' + (task.done ? ' checked' : '') + '>' +
      '<span class="priority-dot"></span>' +
      '<span class="task-text">' + escapeHtml(task.text) + '</span>' +
      '<button type="button" class="task-delete" title="Usuń zadanie" aria-label="Usuń zadanie: ' + escapeHtml(task.text) + '">&times;</button>';

    li.querySelector('.check-input').addEventListener('change', function () {
      toggleTask(task.id);
    });

    li.querySelector('.task-delete').addEventListener('click', function () {
      deleteTask(task.id);
    });

    taskList.appendChild(li);
  });

  updateProgress(tasks);
}

function toggleTask(id) {
  const username = getCurrentUser();
  const tasks = getTasks(username);
  const task = tasks.find(function (t) { return t.id === id; });
  if (task) {
    task.done = !task.done;
    saveTasks(username, tasks);
    renderTasks();
  }
}

function deleteTask(id) {
  const username = getCurrentUser();
  const tasks = getTasks(username).filter(function (t) { return t.id !== id; });
  saveTasks(username, tasks);
  renderTasks();
}

function updateProgress(tasks) {
  const total = tasks.length;
  const done = tasks.filter(function (t) { return t.done; }).length;
  const percent = total === 0 ? 0 : Math.round((done / total) * 100);

  progressText.textContent = done + ' z ' + total + ' ukończonych';
  progressFill.style.width = percent + '%';
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}


window.addEventListener('DOMContentLoaded', function () {
  const currentUser = getCurrentUser();
  if (currentUser) {
    enterDashboard(currentUser);
  } else {
    showSection(loginSection);
  }
});
