﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Net.Mail;
using System.Windows;
using Microsoft.Data.Sqlite;

namespace Kontakty
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new KontaktyViewModel();
        }
    }

    public class Kontakt
    {
        public int Id { get; set; }
        public string Imie { get; set; } = "";
        public string Telefon { get; set; } = "";
        public string Email { get; set; } = "";
    }

    public class BazaDanych
    {
        private string polaczenie;

        public BazaDanych(string sciezka)
        {
            polaczenie = new SqliteConnectionStringBuilder { DataSource = sciezka }.ToString();
        }

        public void Utworz()
        {
            using (SqliteConnection baza = new SqliteConnection(polaczenie))
            {
                baza.Open();
                var sql = baza.CreateCommand();
                sql.CommandText = "CREATE TABLE IF NOT EXISTS Kontakty (Id INTEGER PRIMARY KEY AUTOINCREMENT, Imie TEXT NOT NULL, Telefon TEXT NOT NULL, Email TEXT NOT NULL)";
                sql.ExecuteNonQuery();
            }
        }

        public List<Kontakt> Wczytaj()
        {
            List<Kontakt> kontakty = new List<Kontakt>();
            using (SqliteConnection baza = new SqliteConnection(polaczenie))
            {
                baza.Open();
                var sql = baza.CreateCommand();
                sql.CommandText = "SELECT Id, Imie, Telefon, Email FROM Kontakty ORDER BY Imie, Id";
                using (var dane = sql.ExecuteReader())
                {
                    while (dane.Read())
                    {
                        Kontakt kontakt = new Kontakt();
                        kontakt.Id = dane.GetInt32(0);
                        kontakt.Imie = dane.GetString(1);
                        kontakt.Telefon = dane.GetString(2);
                        kontakt.Email = dane.GetString(3);
                        kontakty.Add(kontakt);
                    }
                }
            }
            return kontakty;
        }

        public void Zapisz(Kontakt kontakt, bool nowy)
        {
            using (SqliteConnection baza = new SqliteConnection(polaczenie))
            {
                baza.Open();
                var sql = baza.CreateCommand();
                if (nowy)
                    sql.CommandText = "INSERT INTO Kontakty (Imie, Telefon, Email) VALUES ($imie, $telefon, $email)";
                else
                {
                    sql.CommandText = "UPDATE Kontakty SET Imie=$imie, Telefon=$telefon, Email=$email WHERE Id=$id";
                    sql.Parameters.AddWithValue("$id", kontakt.Id);
                }
                sql.Parameters.AddWithValue("$imie", kontakt.Imie);
                sql.Parameters.AddWithValue("$telefon", kontakt.Telefon);
                sql.Parameters.AddWithValue("$email", kontakt.Email);
                if (sql.ExecuteNonQuery() != 1)
                    throw new InvalidOperationException("Nie znaleziono kontaktu.");
            }
        }

        public void Usun(int id)
        {
            using (SqliteConnection baza = new SqliteConnection(polaczenie))
            {
                baza.Open();
                var sql = baza.CreateCommand();
                sql.CommandText = "DELETE FROM Kontakty WHERE Id=$id";
                sql.Parameters.AddWithValue("$id", id);
                if (sql.ExecuteNonQuery() != 1)
                    throw new InvalidOperationException("Nie znaleziono kontaktu.");
            }
        }
    }

    public class KontaktyViewModel : INotifyPropertyChanged
    {
        private BazaDanych baza;
        public ObservableCollection<Kontakt> Kontakty { get; } = new ObservableCollection<Kontakt>();
        public Polecenie Nowy { get; }
        public Polecenie Dodaj { get; }
        public Polecenie Zapisz { get; }
        public Polecenie Usun { get; }

        private string imie = "";
        public string Imie
        {
            get { return imie; }
            set { imie = value; Powiadom("Imie"); }
        }

        private string telefon = "";
        public string Telefon
        {
            get { return telefon; }
            set { telefon = value; Powiadom("Telefon"); }
        }

        private string email = "";
        public string Email
        {
            get { return email; }
            set { email = value; Powiadom("Email"); }
        }

        private string komunikat = "";
        public string Komunikat
        {
            get { return komunikat; }
            set { komunikat = value; Powiadom("Komunikat"); }
        }

        private Kontakt? wybrany;
        public Kontakt? Wybrany
        {
            get { return wybrany; }
            set
            {
                wybrany = value;
                Powiadom("Wybrany");
                if (wybrany != null)
                {
                    Imie = wybrany.Imie;
                    Telefon = wybrany.Telefon;
                    Email = wybrany.Email;
                }
            }
        }

        public KontaktyViewModel() : this(Path.Combine(AppContext.BaseDirectory, "kontakty.db")) { }

        public KontaktyViewModel(string sciezka)
        {
            baza = new BazaDanych(sciezka);
            Nowy = new Polecenie(Wyczysc);
            Dodaj = new Polecenie(DodajKontakt);
            Zapisz = new Polecenie(ZapiszKontakt);
            Usun = new Polecenie(UsunKontakt);
            try
            {
                baza.Utworz();
                Odswiez();
            }
            catch (Exception)
            {
                Komunikat = "Nie udało się otworzyć bazy danych.";
            }
        }

        private void Odswiez()
        {
            var lista = baza.Wczytaj();
            Kontakty.Clear();
            foreach (Kontakt kontakt in lista)
                Kontakty.Add(kontakt);
            Wyczysc();
        }

        private void Wyczysc()
        {
            Wybrany = null;
            Imie = "";
            Telefon = "";
            Email = "";
            Komunikat = "";
        }

        private void DodajKontakt()
        {
            ZapiszDane(true);
        }

        private void ZapiszKontakt()
        {
            ZapiszDane(false);
        }

        private void ZapiszDane(bool nowy)
        {
            if (!nowy && Wybrany == null)
            {
                Komunikat = "Zaznacz kontakt do edycji.";
                return;
            }
            if (string.IsNullOrWhiteSpace(Imie) || string.IsNullOrWhiteSpace(Telefon))
            {
                Komunikat = "Podaj imię i telefon.";
                return;
            }
            if (!MailAddress.TryCreate(Email.Trim(), out var adres) || adres.Address != Email.Trim())
            {
                Komunikat = "Podaj poprawny adres e-mail.";
                return;
            }
            try
            {
                Kontakt kontakt = new Kontakt();
                if (!nowy) kontakt.Id = Wybrany!.Id;
                kontakt.Imie = Imie.Trim();
                kontakt.Telefon = Telefon.Trim();
                kontakt.Email = Email.Trim();
                baza.Zapisz(kontakt, nowy);
                Odswiez();
                Komunikat = "Kontakt zapisany.";
            }
            catch (Exception)
            {
                Komunikat = "Nie udało się zapisać lub odświeżyć danych.";
            }
        }

        private void UsunKontakt()
        {
            if (Wybrany == null)
            {
                Komunikat = "Zaznacz kontakt do usunięcia.";
                return;
            }
            try
            {
                baza.Usun(Wybrany.Id);
                Odswiez();
                Komunikat = "Kontakt usunięty.";
            }
            catch (Exception)
            {
                Komunikat = "Nie udało się usunąć lub odświeżyć danych.";
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void Powiadom(string nazwa)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(nazwa));
        }
    }
}
