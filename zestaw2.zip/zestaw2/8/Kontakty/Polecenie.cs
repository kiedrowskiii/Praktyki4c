﻿using System;
using System.Windows.Input;

namespace Kontakty
{
    public class Polecenie : ICommand
    {
        private Action akcja;

        public Polecenie(Action akcja)
        {
            this.akcja = akcja;
        }

        public bool CanExecute(object? parameter)
        {
            return true;
        }

        public void Execute(object? parameter)
        {
            akcja();
        }

        public event EventHandler? CanExecuteChanged
        {
            add { }
            remove { }
        }
    }
}
