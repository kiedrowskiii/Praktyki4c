﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace Galeria
{
    public class Zdjecie
    {
        public string Nazwa { get; set; } = "";
        public string Sciezka { get; set; } = "";
        public BitmapImage Miniaturka { get; set; } = new BitmapImage();
    }
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private BitmapImage WczytajObraz(string sciezka, int szerokosc)
        {
            BitmapImage obraz = new BitmapImage();
            obraz.BeginInit();
            obraz.CacheOption = BitmapCacheOption.OnLoad;
            obraz.DecodePixelWidth = szerokosc;
            obraz.UriSource = new Uri(sciezka);
            obraz.EndInit();
            obraz.Freeze();
            return obraz;
        }

        private void WybierzFolder_Click(object sender, RoutedEventArgs e)
        {
            OpenFolderDialog okno = new OpenFolderDialog();
            okno.Title = "Wybierz folder ze zdjeciami";
            if (okno.ShowDialog(this) == true)
            {
                WczytajFolder(okno.FolderName);
            }
        }

        private void WczytajFolder(string folder)
        {
            string[] pliki;
            try
            {
                pliki = Directory.GetFiles(folder);
                Array.Sort(pliki);
            }
            catch (Exception)
            {
                MessageBox.Show(this, "Nie udalo się otworzyc folderu.");
                return;
            }

            List<Zdjecie> zdjecia = new List<Zdjecie>();
            int pominiete = 0;

            foreach (string plik in pliki)
            {
                string rozszerzenie = Path.GetExtension(plik).ToLower();

                if (rozszerzenie == ".jpg" || rozszerzenie == ".jpeg"
                    || rozszerzenie == ".png" || rozszerzenie == ".bmp"
                    || rozszerzenie == ".gif" || rozszerzenie == ".tif"
                    || rozszerzenie == ".tiff")
                {
                    try
                    {
                        Zdjecie zdjecie = new Zdjecie();
                        zdjecie.Nazwa = Path.GetFileName(plik);
                        zdjecie.Sciezka = plik;
                        zdjecie.Miniaturka = WczytajObraz(plik, 130);
                        zdjecia.Add(zdjecie);
                    }
                    catch (Exception)
                    {
                        pominiete++;
                    }
                }
            }

            Podglad.Source = null;
            ListaZdjec.ItemsSource = zdjecia;
            Informacja.Text = "Wczytano zdjec: " + zdjecia.Count;

            if (zdjecia.Count == 0)
                Informacja.Text = "W folderze nie znaleziono poprawnych zdjec.";
            if (pominiete > 0)
                Informacja.Text += " Pominieto nieczytelnych plikow: " + pominiete;
        }

        private void ListaZdjec_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListaZdjec.SelectedItem == null)
            {
                Podglad.Source = null;
                return;
            }

            Zdjecie zdjecie = (Zdjecie)ListaZdjec.SelectedItem;

            try
            {
                Podglad.Source = WczytajObraz(zdjecie.Sciezka, 1000);
            }
            catch (Exception)
            {
                Podglad.Source = null;
                MessageBox.Show(this, "Nie udało się wyświetlić zdjęcia.");
            }
        }
    }
}
