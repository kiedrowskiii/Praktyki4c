﻿using System.ComponentModel;
using System.Net.Mail;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace Rejestracja
{
    public partial class MainWindow : Window, IDataErrorInfo
    {
        private bool pokazBledy = false;

        public string Imie { get; set; } = "";
        public string Nazwisko { get; set; } = "";
        public string Email { get; set; } = "";
        public string Haslo { get; set; } = "";
        public string Potwierdzenie { get; set; } = "";
        public bool Regulamin { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
        }

        public string Error
        {
            get { return ""; }
        }

        public string this[string pole]
        {
            get
            {
                if (!pokazBledy)
                    return "";

                if (pole == "Imie" && string.IsNullOrWhiteSpace(Imie))
                    return "Podaj imię.";

                if (pole == "Nazwisko" && string.IsNullOrWhiteSpace(Nazwisko))
                    return "Podaj nazwisko.";

                if (pole == "Email")
                {
                    MailAddress adres;
                    if (!MailAddress.TryCreate(Email, out adres) || adres.Address != Email)
                        return "Podaj poprawny adres e-mail.";
                }

                if (pole == "Haslo" && (string.IsNullOrWhiteSpace(Haslo) || Haslo.Length < 8))
                    return "Hasło musi mieć co najmniej 8 znaków.";

                if (pole == "Potwierdzenie")
                {
                    if (Potwierdzenie == "")
                        return "Potwierdź hasło.";
                    if (Potwierdzenie != Haslo)
                        return "Hasła muszą być takie same.";
                }

                if (pole == "Regulamin" && !Regulamin)
                    return "Zaakceptuj regulamin.";

                return "";
            }
        }

        private void Haslo_PasswordChanged(object sender, RoutedEventArgs e)
        {
            Haslo = PoleHasla.Password;
            PoleHasla.GetBindingExpression(TagProperty).UpdateTarget();
            PolePotwierdzenia.GetBindingExpression(TagProperty).UpdateTarget();
        }

        private void Potwierdzenie_PasswordChanged(object sender, RoutedEventArgs e)
        {
            Potwierdzenie = PolePotwierdzenia.Password;
            PolePotwierdzenia.GetBindingExpression(TagProperty).UpdateTarget();
        }

        private void SprawdzFormularz()
        {
            pokazBledy = true;
            PoleImienia.GetBindingExpression(TextBox.TextProperty).UpdateSource();
            PoleNazwiska.GetBindingExpression(TextBox.TextProperty).UpdateSource();
            PoleEmail.GetBindingExpression(TextBox.TextProperty).UpdateSource();
            PoleHasla.GetBindingExpression(TagProperty).UpdateTarget();
            PolePotwierdzenia.GetBindingExpression(TagProperty).UpdateTarget();
            PoleRegulaminu.GetBindingExpression(ToggleButton.IsCheckedProperty).UpdateSource();
        }

        private void Zarejestruj_Click(object sender, RoutedEventArgs e)
        {
            SprawdzFormularz();

            if (this["Imie"] != "" || this["Nazwisko"] != "" || this["Email"] != ""
                || this["Haslo"] != "" || this["Potwierdzenie"] != "" || this["Regulamin"] != "")
            {
                MessageBox.Show("Popraw błędy w formularzu.");
                return;
            }

            MessageBox.Show("Formularz jest poprawny.");
        }
    }
}
