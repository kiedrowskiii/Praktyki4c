﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace Kalkulator
{
    public partial class MainWindow : Window
    {
        double pierwszaLiczba = 0;
        string dzialanie = "";
        bool nowaLiczba = true;
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Cyfra_Click(object sender, RoutedEventArgs e)
        {
            Button przycisk = (Button)sender;

            if (nowaLiczba || PoleWyniku.Text == "0")
            {
                PoleWyniku.Text = "";
                nowaLiczba = false;
            }

            if (PoleWyniku.Text.Length < 16)
            {
                PoleWyniku.Text += przycisk.Content.ToString();
            }
        }

        private void Dzialanie_Click(object sender, RoutedEventArgs e)
        {
            Button przycisk = (Button)sender;

            if (dzialanie != "" && !nowaLiczba)
            {
                Wynik_Click(sender, e);
            }

            pierwszaLiczba = double.Parse(PoleWyniku.Text);
            dzialanie = przycisk.Content.ToString() ?? "";
            nowaLiczba = true;
        }

        private void Wynik_Click(object sender, RoutedEventArgs e)
        {
            if (dzialanie == "" || nowaLiczba)
            {
                return;
            }

            double drugaLiczba = double.Parse(PoleWyniku.Text);
            double wynik = 0;

            if (dzialanie == "+") wynik = pierwszaLiczba + drugaLiczba;
            if (dzialanie == "-") wynik = pierwszaLiczba - drugaLiczba;
            if (dzialanie == "*") wynik = pierwszaLiczba * drugaLiczba;
            if (dzialanie == "/")
            {
                if (drugaLiczba == 0)
                {
                    MessageBox.Show("Nie można dzielic przez zero.");
                    Wyczysc_Click(sender, e);
                    return;
                }
                wynik = pierwszaLiczba / drugaLiczba;
            }

            if (double.IsInfinity(wynik))
            {
                MessageBox.Show("Wynik jest zbyt duży.");
                Wyczysc_Click(sender, e);
                return;
            }
            PoleWyniku.Text = wynik.ToString();
            dzialanie = "";
            nowaLiczba = true;
        }

        private void Wyczysc_Click(object sender, RoutedEventArgs e)
        {
            PoleWyniku.Text = "0";
            pierwszaLiczba = 0;
            dzialanie = "";
            nowaLiczba = true;
        }
    }
}