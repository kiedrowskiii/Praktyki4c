﻿using System;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace Notatnik
{
    public partial class MainWindow : Window
    {
        string sciezka = "";
        bool zmieniono = false;

        public MainWindow()
        {
            InitializeComponent();
        }
        private void Tekst_TextChanged(object sender, TextChangedEventArgs e)
        {
            zmieniono = true;
        }

        private bool CzyKontynuowac()
        {
            if (!zmieniono)
                return true;

            MessageBoxResult odpowiedz = MessageBox.Show(this,
                "Czy zapisać zmiany?", "Notatnik", MessageBoxButton.YesNoCancel);

            if (odpowiedz == MessageBoxResult.Cancel)
                return false;
            if (odpowiedz == MessageBoxResult.Yes)
                return ZapiszPlik(false);

            return true;
        }

        private void Nowy_Click(object sender, RoutedEventArgs e)
        {
            if (!CzyKontynuowac())
                return;

            PoleTekstu.Clear();
            sciezka = "";
            zmieniono = false;
            Title = "Notatnik - Nowy plik";
        }

        private void Otworz_Click(object sender, RoutedEventArgs e)
        {
            if (!CzyKontynuowac())
                return;
            OpenFileDialog okno = new OpenFileDialog();
            okno.Filter = "Pliki tekstowe (*.txt)|*.txt|Wszystkie pliki (*.*)|*.*";

            if (okno.ShowDialog(this) == true)
            {
                try
                {
                    string tekst = File.ReadAllText(okno.FileName);
                    PoleTekstu.Text = tekst;
                    sciezka = okno.FileName;
                    zmieniono = false;
                    Title = "Notatnik - " + Path.GetFileName(sciezka);
                }
                catch (Exception)
                {
                    MessageBox.Show(this, "Nie udało się otworzyć pliku.");
                }
            }
        }

        private bool ZapiszPlik(bool zapiszJako)
        {
            string nowaSciezka = sciezka;
            if (sciezka == "" || zapiszJako)
            {
                SaveFileDialog okno = new SaveFileDialog();
                okno.Filter = "Pliki tekstowe (*.txt)|*.txt|Wszystkie pliki (*.*)|*.*";
                okno.DefaultExt = ".txt";
                okno.FileName = Path.GetFileName(sciezka);

                if (okno.ShowDialog(this) != true)
                    return false;

                nowaSciezka = okno.FileName;
            }
            try
            {
                File.WriteAllText(nowaSciezka, PoleTekstu.Text);
                sciezka = nowaSciezka;
                zmieniono = false;
                Title = "Notatnik - " + Path.GetFileName(sciezka);
                return true;
            }
            catch (Exception)
            {
                MessageBox.Show(this, "Nie udało się zapisać pliku.");
                return false;
            }
        }

        private void Zapisz_Click(object sender, RoutedEventArgs e)
        {
            ZapiszPlik(false);
        }
        private void ZapiszJako_Click(object sender, RoutedEventArgs e)
        {
            ZapiszPlik(true);
        }
        private void Zamknij_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private void Okno_Closing(object sender, CancelEventArgs e)
        {
            if (!CzyKontynuowac())
                e.Cancel = true;
        }
    }
}
