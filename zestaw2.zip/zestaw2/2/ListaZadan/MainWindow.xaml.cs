﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;

namespace ListaZadan
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public ObservableCollection<string> Zadania { get; set; } = new ObservableCollection<string>();
        private string noweZadanie = "";
        public string NoweZadanie
        {
            get { return noweZadanie; }
            set
            {
                noweZadanie = value;
                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("NoweZadanie"));
                }
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
        }

        private void Dodaj_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(NoweZadanie))
            {
                Zadania.Add(NoweZadanie.Trim());
                NoweZadanie = "";
            }
        }

        private void Usun_Click(object sender, RoutedEventArgs e)
        {
            if (Lista.SelectedItem != null)
            {
                Zadania.Remove((string)Lista.SelectedItem);
            }
        }
    }
}
