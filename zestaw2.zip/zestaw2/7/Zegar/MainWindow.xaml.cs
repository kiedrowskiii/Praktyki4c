﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Zegar
{
    public partial class MainWindow : Window
    {
        DispatcherTimer zegar = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();
            NarysujKreski();
            UstawCzas(DateTime.Now);

            zegar.Interval = TimeSpan.FromSeconds(1);
            zegar.Tick += Zegar_Tick;
            zegar.Start();
        }

        private void NarysujKreski()
        {
            for (int i = 0; i < 12; i++)
            {
                Line kreska = new Line();
                kreska.X1 = 120;
                kreska.Y1 = 8;
                kreska.X2 = 120;
                kreska.Y2 = 18;
                kreska.Stroke = Brushes.Black;
                kreska.StrokeThickness = 2;
                kreska.RenderTransform = new RotateTransform(i * 30, 120, 120);
                Tarcza.Children.Add(kreska);
            }
        }

        private void Zegar_Tick(object sender, EventArgs e)
        {
            UstawCzas(DateTime.Now);
        }

        private void UstawCzas(DateTime czas)
        {
            CzasCyfrowy.Text = czas.ToString("HH:mm:ss");
            ObrotSekund.Angle = czas.Second * 6;
            ObrotMinut.Angle = czas.Minute * 6 + czas.Second * 0.1;
            ObrotGodzin.Angle = (czas.Hour % 12) * 30 + czas.Minute * 0.5 + czas.Second / 120.0;
        }

        private void Okno_Closed(object sender, EventArgs e)
        {
            zegar.Stop();
        }
    }
}
