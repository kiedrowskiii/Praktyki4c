﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;

namespace Konwerter
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Jednostki.SelectedIndex = 0;
        }
        private void Wartosc_TextChanged(object sender, TextChangedEventArgs e)
        {
            Przelicz();
        }
        private void Jednostki_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Przelicz();
        }

        private void Przelicz()
        {
            if (Wartosc == null || Wynik == null)
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(Wartosc.Text))
            {
                Wynik.Text = "";
                return;
            }

            double liczba;
            string tekst = Wartosc.Text.Replace(',', '.');

            if (!double.TryParse(tekst, NumberStyles.Float, CultureInfo.InvariantCulture, out liczba)
                || double.IsNaN(liczba) || double.IsInfinity(liczba))
            {
                Wynik.Text = "Wpisz poprawną liczbę.";
                return;
            }

            if (Jednostki.SelectedIndex < 4 && liczba < 0)
            {
                Wynik.Text = "Długość i masa nie mogą być ujemne.";
                return;
            }

            double wynik = 0;
            string jednostka = "";

            switch (Jednostki.SelectedIndex)
            {
                case 0:
                    wynik = liczba / 1.609344;
                    jednostka = "mile";
                    break;
                case 1:
                    wynik = liczba * 1.609344;
                    jednostka = "km";
                    break;
                case 2:
                    wynik = liczba / 0.45359237;
                    jednostka = "lb";
                    break;
                case 3:
                    wynik = liczba * 0.45359237;
                    jednostka = "kg";
                    break;
                case 4:
                    wynik = liczba * 1.8 + 32;
                    jednostka = "°F";
                    break;
                case 5:
                    wynik = (liczba - 32) / 1.8;
                    jednostka = "°C";
                    break;
            }

            if (double.IsInfinity(wynik))
            {
                Wynik.Text = "Wartość jest zbyt duza.";
                return;
            }
            Wynik.Text = wynik.ToString("G10", CultureInfo.GetCultureInfo("pl-PL")) + " " + jednostka;
        }
    }
}
