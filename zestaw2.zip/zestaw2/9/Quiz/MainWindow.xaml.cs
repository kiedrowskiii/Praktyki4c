﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows;

namespace Quiz
{
    public class Pytanie
    {
        public string Tresc { get; set; } = "";
        public List<string> Odpowiedzi { get; set; } = new List<string>();
        public int PoprawnaOdpowiedz { get; set; } = -1;
    }

    public partial class MainWindow : Window
    {
        List<Pytanie> pytania = new List<Pytanie>();
        int numerPytania = 0;
        int punkty = 0;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += Okno_Loaded;
        }

        private void Okno_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                string sciezka = Path.Combine(AppContext.BaseDirectory, "pytania.json");
                string tekst = File.ReadAllText(sciezka);
                pytania = JsonSerializer.Deserialize<List<Pytanie>>(tekst) ?? new List<Pytanie>();

                if (pytania.Count == 0)
                    throw new Exception("Plik nie zawiera pytań.");

                foreach (Pytanie pytanie in pytania)
                {
                    if (pytanie == null || string.IsNullOrWhiteSpace(pytanie.Tresc)
                        || pytanie.Odpowiedzi == null || pytanie.Odpowiedzi.Count != 4
                        || pytanie.PoprawnaOdpowiedz < 0 || pytanie.PoprawnaOdpowiedz > 3)
                        throw new Exception("Każde pytanie musi mieć treść, cztery odpowiedzi i poprawny numer odpowiedzi (0–3).");

                    foreach (string odpowiedz in pytanie.Odpowiedzi)
                    {
                        if (string.IsNullOrWhiteSpace(odpowiedz))
                            throw new Exception("Odpowiedzi nie mogą być puste.");
                    }
                }

                PokazPytanie();
            }
            catch (Exception blad)
            {
                MessageBox.Show(this, "Nie udało się wczytać pytań.\n" + blad.Message);
                Close();
            }
        }

        private void PokazPytanie()
        {
            Pytanie pytanie = pytania[numerPytania];
            PanelPytania.Visibility = Visibility.Visible;
            PanelWyniku.Visibility = Visibility.Collapsed;
            Postep.Text = "Pytanie " + (numerPytania + 1) + " z " + pytania.Count;
            Punkty.Text = "Punkty: " + punkty;
            TrescPytania.Text = pytanie.Tresc;
            TekstA.Text = pytanie.Odpowiedzi[0];
            TekstB.Text = pytanie.Odpowiedzi[1];
            TekstC.Text = pytanie.Odpowiedzi[2];
            TekstD.Text = pytanie.Odpowiedzi[3];
            OdpowiedzA.IsChecked = false;
            OdpowiedzB.IsChecked = false;
            OdpowiedzC.IsChecked = false;
            OdpowiedzD.IsChecked = false;
            Komunikat.Text = "";
            Dalej.Content = "Dalej";
            if (numerPytania == pytania.Count - 1)
                Dalej.Content = "Zakończ";
        }

        private void Dalej_Click(object sender, RoutedEventArgs e)
        {
            if (numerPytania >= pytania.Count)
                return;

            int odpowiedz = -1;
            if (OdpowiedzA.IsChecked == true) odpowiedz = 0;
            if (OdpowiedzB.IsChecked == true) odpowiedz = 1;
            if (OdpowiedzC.IsChecked == true) odpowiedz = 2;
            if (OdpowiedzD.IsChecked == true) odpowiedz = 3;

            if (odpowiedz == -1)
            {
                Komunikat.Text = "Zaznacz odpowiedź.";
                return;
            }

            if (odpowiedz == pytania[numerPytania].PoprawnaOdpowiedz)
                punkty++;
            numerPytania++;

            if (numerPytania < pytania.Count)
            {
                PokazPytanie();
            }
            else
            {
                PanelPytania.Visibility = Visibility.Collapsed;
                PanelWyniku.Visibility = Visibility.Visible;
                Wynik.Text = "Poprawne odpowiedzi: " + punkty + " z " + pytania.Count;
                Bledy.Text = "Błędne odpowiedzi: " + (pytania.Count - punkty);
                Procent.Text = "Wynik: " + Math.Round(punkty * 100.0 / pytania.Count) + "%";
            }
        }

        private void Ponownie_Click(object sender, RoutedEventArgs e)
        {
            numerPytania = 0;
            punkty = 0;
            PokazPytanie();
        }
    }
}
