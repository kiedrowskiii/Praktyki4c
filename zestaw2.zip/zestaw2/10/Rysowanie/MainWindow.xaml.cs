﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Rysowanie
{
    public partial class MainWindow : Window
    {
        Point poczatek;
        Shape? rysunek;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Obszar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton != MouseButton.Left || rysunek != null)
                return;

            poczatek = e.GetPosition(Obszar);

            if (Ksztalt.SelectedIndex == 0)
                rysunek = new Line();
            if (Ksztalt.SelectedIndex == 1)
                rysunek = new Rectangle();
            if (Ksztalt.SelectedIndex == 2)
                rysunek = new Ellipse();

            if (rysunek == null)
                return;

            rysunek.Stroke = Brushes.Black;
            if (Kolor.SelectedIndex == 1) rysunek.Stroke = Brushes.Red;
            if (Kolor.SelectedIndex == 2) rysunek.Stroke = Brushes.Green;
            if (Kolor.SelectedIndex == 3) rysunek.Stroke = Brushes.Blue;

            ComboBoxItem grubosc = (ComboBoxItem)Grubosc.SelectedItem;
            rysunek.StrokeThickness = double.Parse(grubosc.Content.ToString()!);
            rysunek.IsHitTestVisible = false;
            Obszar.Children.Add(rysunek);
            ZmienRozmiar(poczatek);
            Obszar.CaptureMouse();
        }

        private void Obszar_MouseMove(object sender, MouseEventArgs e)
        {
            if (rysunek != null && e.LeftButton == MouseButtonState.Pressed)
                ZmienRozmiar(e.GetPosition(Obszar));
        }

        private void ZmienRozmiar(Point koniec)
        {
            if (rysunek == null)
                return;

            if (rysunek is Line linia)
            {
                linia.X1 = poczatek.X;
                linia.Y1 = poczatek.Y;
                linia.X2 = koniec.X;
                linia.Y2 = koniec.Y;
            }
            else
            {
                double szerokosc = Math.Abs(koniec.X - poczatek.X);
                double wysokosc = Math.Abs(koniec.Y - poczatek.Y);

                if (rysunek is Ellipse)
                {
                    double bok = Math.Min(szerokosc, wysokosc);
                    szerokosc = bok;
                    wysokosc = bok;
                }

                double lewo = poczatek.X;
                double gora = poczatek.Y;
                if (koniec.X < poczatek.X) lewo -= szerokosc;
                if (koniec.Y < poczatek.Y) gora -= wysokosc;

                Canvas.SetLeft(rysunek, lewo);
                Canvas.SetTop(rysunek, gora);
                rysunek.Width = szerokosc;
                rysunek.Height = wysokosc;
            }
        }

        private void Obszar_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton != MouseButton.Left || rysunek == null)
                return;

            ZmienRozmiar(e.GetPosition(Obszar));
            rysunek = null;
            Obszar.ReleaseMouseCapture();
        }

        private void Obszar_LostMouseCapture(object sender, MouseEventArgs e)
        {
            rysunek = null;
        }

        private void Wyczysc_Click(object sender, RoutedEventArgs e)
        {
            rysunek = null;
            Obszar.ReleaseMouseCapture();
            Obszar.Children.Clear();
        }
    }
}
